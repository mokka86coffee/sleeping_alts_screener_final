# Патч 2 · диагностика, отчёт, журнал

Три независимых блока.

---

## 1 · Причины отказа перестают теряться

Сейчас `failures` в сигнале заполняется только при исключении внутри
подкейса и при отсутствии потолка в `CASE_CAP`. Штатный отказ идёт через
`if sig is None: continue` — молча. При этом причина существует и
вычисляется: `veto_common` и `veto_bullish` возвращают текст, а подкейс
его выбрасывает.

Отсюда пустая колонка `failures` у всех 174 монет в пробе и
невозможность понять, почему `hidden` и `spring` замолчали. Пустота при
этом означала хорошее — ни один подкейс не падает.

Правится в трёх местах: копилка в контексте, перенос в диспетчере,
и сами подкейсы (`flow_hidden.py` и `flow_spring.py` приложены
отдельными файлами целиком).

### 1.1 · Копилка в контексте

`detectors/flow_core.py`, класс `FlowContext`. Вставить после поля
`horizon_bars` (строка 1279), до первого `@property`.

#### стало

```python
    # Причины штатных отказов подкейсов. Пишутся reject(), диспетчер
    # переносит их в failures сигнала.
    #
    # Отдельно от возврата: контракт «SubcaseSignal либо None» ломать
    # нельзя — диспетчер третьего состояния не знает, и объект с
    # флагом отказа он положил бы в results наравне с фигурой.
    # Поэтому None остаётся None, а причина уезжает боковым каналом.
    notes: dict[str, str] = field(default_factory=dict)

    def reject(self, who: str, reason: str) -> None:
        """Записывает причину отказа и возвращает None.

        Возврат именно None, а не self: подкейс пишет
        `return ctx.reject(NAME, "...")` одной строкой, и контракт
        снаружи не меняется.
        """
        self.notes[who] = reason
        return None
```

### 1.2 · Перенос в диспетчере

`detectors/flow.py`, `detect_flow`. Вставить сразу после цикла
`for module in _RUNNERS:` — перед строкой `cases = {`.

#### стало

```python
    # Штатные отказы: подкейс вернул None и записал, почему.
    # setdefault, а не присваивание: исключение важнее отказа по
    # порогу, и если модуль успел записать причину до падения,
    # затирать текст ошибки нельзя.
    for mod_name, reason in (getattr(ctx, "notes", None) or {}).items():
        failures.setdefault(mod_name, reason)
```

### 1.3 · Проба: причины в дамп

`flow_probe.py` уже читает `d.get("failures")` и кладёт в колонку —
менять не нужно. После правок 1.1–1.2 колонка перестанет быть пустой
сама.

Стоит только проверить: `FIELDS` содержит `failures`, а сводка по
`fail_counter` печатается в конце. Если счётчик выводит теперь сотни
строк вида «нет живых зон», это не поломка, а первый честный ответ на
вопрос, почему семейство молчит.

---

## 2 · Режим рынка перестаёт быть константой

Обе точки чтения запрашивают ключ `label`, которого в снимке нет:
`build_market_regime` в `run.py` кладёт `regime`. `.get` каждый раз
возвращает дефолт, и «RISK-OFF» на геройском экране — это строковый
литерал из кода, а не состояние рынка. Он стоит там при любом рынке.

Дальше по цепочке `calm` в `_orbit_market` вычисляется из того же
`label`, всегда получается `False`, и брифинг всегда печатает «Сегодня
фон осторожный». Тоже константа, выглядящая как вывод.

**Перед правкой сверься одной строкой:** `grep -n "regime" run.py` в
месте `build_market_regime`. Если там всё-таки `label`, эта правка
отменяется целиком.

### 2.1 · Шапка дашборда

`render/dashboard.py`, `_head`, строки 368 и 381.

#### было

```python
    # Источник — snapshot.market_regime (dict: label / appetite / text).
```

```python
    label = str(reg.get("label", "risk-off")).upper()
```

#### стало

```python
    # Источник — snapshot.market_regime (dict: regime / appetite / note
    # и далее — см. build_market_regime в run.py).
```

```python
    # Ключ именно regime. Раньше спрашивался label, которого в снимке
    # нет: .get молча возвращал дефолт, и капсула показывала «RISK-OFF»
    # при любом состоянии рынка — константу, неотличимую от данных.
    # Дефолт оставлен пустым сознательно: отсутствующее значение должно
    # выглядеть отсутствующим, а не как режим.
    label = str(reg.get("regime", "") or "—").upper()
```

### 2.2 · Орбита

`render/orbit.py`, `_orbit_market`, строки 415 и docstring выше.

#### было

```python
    Режим и аппетит лежат в snapshot.market_regime (словарь: label /
    appetite / text) — тот же источник, что читает _head() для капсулы
    в шапке дашборда. Раньше я пробовал их как плоские атрибуты
    snapshot.regime / snapshot.appetite, которых не существует.
```

```python
    label = str(reg.get("label", "risk-off"))
```

#### стало

```python
    Режим и аппетит лежат в snapshot.market_regime (словарь: regime /
    appetite / note / green_share / …) — тот же источник, что читает
    _head() для капсулы в шапке дашборда. Ключ режима называется
    regime; label в снимке никогда не существовал, и запрос по нему
    молча отдавал дефолт «risk-off» — экран показывал константу.
```

```python
    label = str(reg.get("regime", "") or "")
```

### 2.3 · `calm` перестаёт быть всегда ложным

`render/orbit.py`, строка 417.

С пустым дефолтом `startswith("RISKON")` даст `False` и на отсутствии
данных, и на реальном risk-off — а это разные вещи. Отсутствие данных
не должно читаться как осторожный рынок.

#### было

```python
        # «спокойный» и «осторожный» — пересказ режима, а не прогноз
        "calm": label.upper().replace("-", "").startswith("RISKON"),
```

#### стало

```python
        # «спокойный» и «осторожный» — пересказ режима, а не прогноз.
        # None при пустом режиме: брифинг тогда пропустит фразу целиком,
        # а не назовёт фон осторожным на основании отсутствия данных.
        "calm": (
            label.upper().replace("-", "").startswith("RISKON")
            if label else None
        ),
```

### 2.4 · Брифинг уважает «неизвестно»

`render/brief.py`, строки 122 и 191–194.

#### было

```javascript
    var calm = !!M.calm;
```

#### стало

```javascript
    // Три состояния, а не два: null означает «режим неизвестен».
    // Прежнее !!M.calm сводило неизвестность к «осторожно» и печатало
    // вывод там, где данных нет.
    var calm = (M.calm === null || M.calm === undefined) ? null : !!M.calm;
```

Фразу про фон в строках 191–194 оберни условием `calm !== null` — при
неизвестном режиме предложение просто не печатается. Точное место
зависит от того, как у тебя собран массив фраз, поэтому фрагмент не
даю: правка на одну строку в том же стиле, что соседние.

---

## 3 · Журнал: план обновляется, MFE/MAE сходится с ценами

`analytics/leaders.py`. Два блока.

### 3.1 · Поля плана обновляются каждый прогон

Строки с `rec.get("zone_price") or ...`. Сейчас все четыре поля
пишутся один раз и больше не трогаются: цена уходит, уровень остаётся.
В журнале от этого три записи со стопом ВЫШЕ текущей цены — BICO на
+7.2%, GUA на +10.0%, SKYAI на +20.2%. Стоп в двадцати процентах над
ценой планом сделки не является.

#### было

```python
            rec = flow_store[leader.symbol]
            f = leader.flow or {}
            rec["entry_case"] = rec.get("entry_case") or f.get("case", "")
            rec["zone_price"] = rec.get("zone_price") or float(f.get("zone_price") or 0.0)
            rec["stop_hint"] = rec.get("stop_hint") or float(f.get("stop_hint") or 0.0)
            rec["target_hint"] = rec.get("target_hint") or float(f.get("target_hint") or 0.0)
            rec["horizon_days"] = rec.get("horizon_days") or int(f.get("horizon_days") or 0)
            rec["horizon_tf"] = rec.get("horizon_tf") or f.get("horizon_tf", "")
```

#### стало

```python
            rec = flow_store[leader.symbol]
            f = leader.flow or {}

            # Кейс входа фиксируется навсегда: это факт о моменте
            # попадания в журнал, и переписывать его нельзя — иначе
            # нечем отвечать на вопрос «через какую фигуру зашли».
            rec["entry_case"] = rec.get("entry_case") or f.get("case", "")

            # А план — состояние на СЕЙЧАС, и он обязан обновляться.
            # Прежнее `rec.get(...) or ...` замораживало уровень в
            # момент первого попадания: цена уходила, зона оставалась,
            # и в журнале появлялись стопы выше текущей цены.
            # Ноль от детектора не затирает прошлое значение — это
            # «не посчитали», а не «уровня нет».
            for key in ("zone_price", "stop_hint", "target_hint"):
                fresh = float(f.get(key) or 0.0)
                if fresh > 0:
                    rec[key] = fresh

            fresh_days = int(f.get("horizon_days") or 0)
            if fresh_days > 0:
                rec["horizon_days"] = fresh_days
                rec["horizon_tf"] = f.get("horizon_tf", "")
```

### 3.2 · MFE и MAE пересчитываются из цен

`_touch_price`. Сейчас `max_change_pct` записывается только в момент
установки нового максимума. Если запись однажды разошлась с ценами —
она такой и останется навсегда: у `PROMUSDT` стоит +23.22 при
собственных ценах, дающих +489.79, и исправиться это не может, пока
монета не сходит выше `max_price` = 12.28.

Пересчёт из цен на каждом прогоне делает расхождение невозможным в
принципе.

#### было

```python
def _touch_price(rec: dict, price: float, now: datetime) -> None:
    entry = rec["entry_price"]
    rec["price"] = price
    rec["change_pct"] = round((price / entry - 1) * 100, 2) if entry > 0 else 0.0
    if price > rec.get("max_price", entry):
        rec["max_price"] = price
        rec["max_change_pct"] = rec["change_pct"]
    if price < rec.get("min_price", entry):
        rec["min_price"] = price
        rec["min_change_pct"] = rec["change_pct"]
    rec["last_seen"] = now.isoformat()
```

#### стало

```python
def _touch_price(rec: dict, price: float, now: datetime) -> None:
    """Обновляет цену и производные от неё величины.

    MFE и MAE пересчитываются из ЦЕН на каждом прогоне, а не пишутся
    один раз в момент нового экстремума. Прежняя версия допускала
    вечное расхождение: если проценты однажды разошлись с ценами
    (ручная правка файла, сбой записи), исправиться они могли только
    после нового экстремума, то есть практически никогда. У PROMUSDT
    так и стоит +23.22 при ценах, дающих +489.79.

    Экстремумы цен по-прежнему только растут — это факты истории.
    Пересчитываются лишь проценты, которые из них выводятся.
    """
    entry = float(rec.get("entry_price") or 0.0)
    rec["price"] = price

    if price > rec.get("max_price", entry):
        rec["max_price"] = price
    if price < rec.get("min_price", entry):
        rec["min_price"] = price

    if entry > 0:
        rec["change_pct"] = round((price / entry - 1) * 100, 2)
        rec["max_change_pct"] = round(
            (float(rec.get("max_price") or entry) / entry - 1) * 100, 2,
        )
        rec["min_change_pct"] = round(
            (float(rec.get("min_price") or entry) / entry - 1) * 100, 2,
        )
    else:
        rec["change_pct"] = 0.0

    rec["last_seen"] = now.isoformat()
```

### 3.3 · Что делать с самой записью PROM

Правка 3.2 пересчитает проценты из цен — они станут +489.79 и −56.19.
Но сами `max_price` 12.28 и `min_price` 0.912 введены руками и историей
монеты не подтверждены, так что честнее их обнулить до входа и дать
журналу набрать заново.

Выполнить один раз, вручную, в `output/leaders.json` для `PROMUSDT`:
`max_price` и `min_price` приравнять к `entry_price` (2.08211),
`max_change_pct` и `min_change_pct` поставить в `0.0`. Флаг
`added_manually` оставить — он и объясняет, откуда взялась запись.
